package se.joel.sailfinlogviewer.parser;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;


public class Log {
    private List<LogRecord> logRecords = new ArrayList<LogRecord>();
    private String name;

    /**
     *
     * @param logRecords
     */
    public Log(String name, List<LogRecord> logRecords) {
        this.name = name;
        this.logRecords = logRecords;
    }

    /**
     * Gets the indices of log records matching the regular expression.
     *
     * @return the logRecords
     * @throws FilterException
     */
    public static List<Integer> findMatchingIndices(String regex, Iterable<LogRecord> logRecords) throws FilterException {
        List<Integer> matchingIndices = new ArrayList<Integer>();

        try {
            if ((regex != null) && (regex.trim().length() > 0)) {
                Pattern pattern = Pattern.compile(".*" + regex + ".*");

                for (LogRecord logRecord : logRecords) {
                    if (pattern.matcher(logRecord.getRawLine().replace('\n', ' ')).matches()) {
                        matchingIndices.add(logRecord.getIndex());
                    }
                }

                return matchingIndices;
            }

            return matchingIndices;
        } catch (PatternSyntaxException e) {
            throw new FilterException("Could not compile regular expression", e);
        }
    }

    /**
     * Gets the parsed records.
     *
     * @return the logRecords
     * @throws FilterException
     */
    public Iterable<LogRecord> getLogRecords(String regex) throws FilterException {
        try {
            if ((regex != null) && (regex.trim().length() > 0)) {
                Pattern pattern = Pattern.compile(".*" + regex + ".*");
                List<LogRecord> filteredRecords = new ArrayList<LogRecord>();

                for (LogRecord logRecord : logRecords) {
                    if (pattern.matcher(logRecord.getRawLine().replace('\n', ' ')).matches()) {
                        filteredRecords.add(logRecord);
                    }
                }

                return filteredRecords;
            } else {
                return logRecords;
            }
        } catch (PatternSyntaxException e) {
            throw new FilterException("Could not compile regular expression", e);
        }
    }

    public static class FilterException extends Exception {
        private static final long serialVersionUID = 1L;

        public FilterException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    public String getName() {
        return name;
    }

    public int size() {
        return logRecords.size();
    }
}
