package se.joel.sailfinlogviewer.gui;

public interface FilterHandler {
    void setFilter();
}
