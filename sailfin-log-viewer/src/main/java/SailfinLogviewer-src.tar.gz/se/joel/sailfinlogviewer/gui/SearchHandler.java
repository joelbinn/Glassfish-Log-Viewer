package se.joel.sailfinlogviewer.gui;



public interface SearchHandler {
    void jumpToNextMatching();
}
