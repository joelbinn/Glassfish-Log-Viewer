package se.joel.sailfinlogviewer.gui;

import java.awt.BorderLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import se.joel.sailfinlogviewer.parser.Log;
import se.joel.sailfinlogviewer.parser.LogParser;
import se.joel.sailfinlogviewer.parser.LogParser.LogParserException;
import se.joel.sailfinlogviewer.util.ToolState;


public class LogViewerMainFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private static Logger logger = Logger.getLogger("GUI");
    private LogViewerMainPanel mainView;
    private ToolState toolState;

    public LogViewerMainFrame(ToolState toolState) throws HeadlessException {
        this.toolState = toolState;
        mainView = new LogViewerMainPanel(toolState);
        getContentPane().add(mainView, BorderLayout.CENTER);

        JMenuBar menuBar = createMenuBar();
        getContentPane().add(menuBar, BorderLayout.NORTH);

        addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    try {
                        LogViewerMainFrame.this.toolState.savePosAndSize(LogViewerMainFrame.class.toString(), LogViewerMainFrame.this);
                    } catch (FileNotFoundException e1) {
                        // Not so important, ignore it
                        logger.log(Level.WARNING, "Failed to save position and size", e1);
                    } catch (IOException e1) {
                        // Not so important, ignore it
                        logger.log(Level.WARNING, "Failed to save position and size", e1);
                    }
                    System.exit(0);
                }
            });
        if (!toolState.restorePosAndSize(this.getClass().toString(), this)) {
            pack();
        }
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        menuBar.add(fileMenu);

        JMenuItem openFileItem = new JMenuItem("Open file...");
        fileMenu.add(openFileItem);
        openFileItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JFileChooser fc = new JFileChooser();
                    File lastSelectedFile = toolState.getLastSelectedFile();

                    if (lastSelectedFile != null) {
                        fc.setSelectedFile(lastSelectedFile);
                    }

                    int returnVal = fc.showOpenDialog(LogViewerMainFrame.this);

                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        File file = fc.getSelectedFile();
                        LineNumberReader reader = null;

                        try {
                            reader = new LineNumberReader(new FileReader(file));

                            LogParser logParser = new LogParser(file.getAbsolutePath(), reader);
                            Log log = logParser.parse();
                            mainView.setLog(log);
                            toolState.setLastSelectedFile(file);
                        } catch (FileNotFoundException e1) {
                            JOptionPane.showMessageDialog(LogViewerMainFrame.this, "Could not open file: " + file + ": " + e1);
                        } catch (LogParserException e2) {
                            JOptionPane.showMessageDialog(LogViewerMainFrame.this, "Could not parse file: " + file + ": " + e2);
                        } catch (IOException e3) {
                            JOptionPane.showMessageDialog(LogViewerMainFrame.this, "Could not parse file: " + file + ": " + e3);
                        } finally {
                            if (reader != null) {
                                try {
                                    reader.close();
                                } catch (IOException e1) {
                                    // Ignore
                                }
                            }
                        }
                    }
                }
            });

        JMenu toolMenu = new JMenu("Tools");
        menuBar.add(toolMenu);

        JMenuItem searchAgainFileItem = new JMenuItem(new SearchAction(mainView));
        toolMenu.add(searchAgainFileItem);

        JMenuItem toggleTagItem = new JMenuItem(new ToggleTagAction(mainView));
        toolMenu.add(toggleTagItem);

        JMenuItem toggleShowOnlyTags = new JMenuItem(new ToggleShowOnlyTagsAction(mainView));
        toolMenu.add(toggleShowOnlyTags);

        JMenuItem nextTagItem = new JMenuItem(new GotoNextTagAction(mainView));
        toolMenu.add(nextTagItem);

        JMenuItem prevTagItem = new JMenuItem(new GotoPrevTagAction(mainView));
        toolMenu.add(prevTagItem);

        JMenuItem clearTagsItem = new JMenuItem(new ClearTagsAction(mainView));
        toolMenu.add(clearTagsItem);
        return menuBar;
    }
}
